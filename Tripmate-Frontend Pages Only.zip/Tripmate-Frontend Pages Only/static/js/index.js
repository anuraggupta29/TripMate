setTimeout(function() {
    window.location='form.html';
    },8000);