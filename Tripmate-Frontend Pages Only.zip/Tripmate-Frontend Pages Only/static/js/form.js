//SEND SELECTED STATE, CITY TO THE NEXT PAGE
document.querySelector('.submitButton').addEventListener('click',function(){
    
});