1. CSS of PublicPlacelist has been updated
2. CSS of selected list has been updated
3. New images have been added
4. JS of PublicPlaceList has been updated
5. Details page is complete.
6. 2 images in details page are loaded from js, 3 from html.