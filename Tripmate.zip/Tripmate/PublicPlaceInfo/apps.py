from django.apps import AppConfig


class PublicplaceinfoConfig(AppConfig):
    name = 'PublicPlaceInfo'
