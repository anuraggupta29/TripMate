setTimeout(function() {
    window.location.href='tripMateForm';
    },8000);